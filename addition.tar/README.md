# Addition

Addition block for the Quaisr platform implemented in Python.

## Inputs
* **lhs**: first number to be added.
* **rhs**: second number to be added.

## Outputs
* **sum**: the sum of **lhs** and **rhs**.
